import json
import boto3
import os
from decimal import Decimal
from datetime import datetime, timezone

# Use the internal hostname for LocalStack
endpoint_url = f"http://{os.environ.get('LOCALSTACK_HOSTNAME')}:4566" if os.environ.get('LOCALSTACK_HOSTNAME') else None
dynamodb = boto3.resource('dynamodb', endpoint_url=endpoint_url)
table = dynamodb.Table('DeviceTelemetry')

def lambda_handler(event, context):
    """Process IoT telemetry and store in DynamoDB"""
    
    # MQTT messages usually come as a direct dict or a string
    if isinstance(event, str):
        payload = json.loads(event, parse_float=Decimal)
    else:
        payload = json.loads(json.dumps(event), parse_float=Decimal)
    
    # Ensure mandatory keys exist
    if 'device_id' not in payload:
        payload['device_id'] = 'esp32-001'
    
    # Add timestamp (UTC ISO format)
    payload['timestamp'] = datetime.now(timezone.utc).isoformat()
    
    # Store in DynamoDB
    try:
        # Store in DynamoDB
        table.put_item(Item=payload)
        print(f"✅ Successfully stored: {payload}")
    except Exception as e:
        print(f"❌ DynamoDB Error: {str(e)}") # This will now show up in docker logs
        return {'statusCode': 500, 'body': str(e)}
    
    return {
        'statusCode': 200,
        'body': json.dumps('Telemetry stored successfully')
    }